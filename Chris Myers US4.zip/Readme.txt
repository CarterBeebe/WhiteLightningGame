The DisplayDeathHUD is the function that sets the HUD to be visible. 
This should be placed within the check death function to display the HUD when user health is 0.
The DeathHUD is the HUD itself and will need to be placed inside the blueprint folder in WhiteLightning